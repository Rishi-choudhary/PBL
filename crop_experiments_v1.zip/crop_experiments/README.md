# Crop recommendation experiments (PBL)

Code, data and figures for the paper. Everything runs from this folder.

```
data/                      Kaggle CSV, district dataset, build script, data card
common.py                  model zoo, metrics, statistics, conformal, figure style
01_eda_kaggle.py           why the Kaggle benchmark is saturated
02_benchmark_kaggle.py     16 models x 25 CV splits + significance tests
03_adaboost_diagnosis.py   why AdaBoost collapses on 22 classes
04_robustness_kaggle.py    learning curve, measurement noise, feature ablation
05_explainability_kaggle.py SHAP / permutation / gain + stability (Kendall's W)
06_uncertainty_kaggle.py   calibration (ECE) + conformal prediction sets
07_district_experiments.py real data: random vs district vs state vs temporal validation
08_district_ranking.py     real data: crops ranked per district-year (LambdaRank, NDCG@3)
results/kaggle/            figures (PNG 300 dpi + PDF) and tables (CSV + LaTeX)
(--smoke-test on 07/08 checks the pipeline with FAKE features; those figures are watermarked)
```

## Running

```bash
pip install -r requirements.txt
./run_all.sh                 # ~30 min on 2 CPU cores
```

On Google Colab: upload the folder, `!pip install -r requirements.txt`, then run the scripts with `!python 01_eda_kaggle.py` etc.

TabPFN (needs internet for weights, so Colab, not this workspace):
```bash
pip install tabpfn "tabpfn-extensions[many_class]"
python 02_benchmark_kaggle.py --tabpfn --out results/kaggle_tabpfn
python 07_district_experiments.py --tabpfn
```
TabPFN-2.5/2.6 support at most 10 classes natively; with 22 crops the code wraps it in `ManyClassClassifier` automatically.

Real district experiments, once soil/climate files exist:
```bash
python data/build_dataset.py --icrisat data/ICRISAT_district_level_data.csv \
    --soil soil_district.csv --climate climate_district_year.csv --out data/build
cp data/build/crop_wide_district_year.csv data/
python 07_district_experiments.py                        # 2010-2017, temporal cutoff 2014
python 08_district_ranking.py
python 07_district_experiments.py --feature-prefixes soil_ --out results/district_soil_only
python 07_district_experiments.py --feature-prefixes clim_ --out results/district_climate_only
```

## Which figure goes where

| Paper section | Figure / table |
|---|---|
| Dataset: limits of the benchmark | fig01 feature ranges, fig02 separability, fig03 correlation, tab01_distribution_summary |
| Results: model comparison | fig04 model comparison, tab02_benchmark_paper (.tex ready), fig05 cost vs F1 |
| Results: error analysis | fig06 confusion matrix, fig07 per-crop F1 |
| Discussion: AdaBoost anomaly | fig08, tab03 |
| Robustness | fig09 learning curve + noise, fig10 ablation |
| Explainability | fig11 importance + stability, fig12 per-crop SHAP |
| Uncertainty | fig13 calibration + conformal, tab06 |
| Main contribution (real data) | figD1–figD6, tabD1–tabD5 from 07 (pending soil data) |
| Recommendation as ranking | figD7, tabD6 from 08 (pending soil data) |

## Kaggle results (all numbers produced by these scripts)

- 2,200 rows, 22 crops x 100, no duplicates, no missing values.
- Within every crop, 0 of 154 crop-feature cells pass a normality test, while 82–100% (by feature) are consistent with a uniform distribution (exact KS test on interior points). This is consistent with values sampled uniformly within crop-specific ranges, not with field measurements. State it as "consistent with"; it is not proof.
- Benchmark (5x5 repeated stratified CV): best is Stacking at 99.57% ± 0.26 accuracy. 11 of 16 models are not significantly worse (corrected resampled t-test, Holm). This includes Gaussian Naive Bayes (99.47%, fit time ~0 s) and a single decision tree (98.80%). Significantly worse: SVM, logistic regression, KNN, MLP.
- Learning curve: Random Forest reaches 0.974 macro-F1 with 8 samples per crop; Gaussian NB 0.992 with 16.
- Noise: with test noise of 0.2 x feature std, LightGBM falls to 0.773, RF 0.872, SVM 0.947, LR 0.921. The ranking on clean data does not survive noise.
- Ablation (RF): climate-only 0.918 vs soil-only 0.788 macro-F1; dropping N changes nothing (0.995).
- AdaBoost: scikit-learn's default base learner (depth-1 stump) gives 20–25% on 22 classes; with depth-3 trees 99.1%. AdaBoost on SVM gives 88.5% and on NB 97.8%, both worse than the base learner alone. The report's Fig 7.2 values (0.886 and 0.975) are close to these; the 21.36% in Table 8.3 falls in the range of the default-stump configuration. This suggests, but does not prove, that Table 8.3 came from default AdaBoost.
- Explanations on random folds are stable (SHAP Kendall's W = 0.97; humidity ranked first in 10/10 splits).
- Calibration: isotonic recalibration lowers ECE for SVM 0.110 → 0.007 and RF 0.040 → 0.004.
- Conformal (LightGBM, alpha = 0.10): LAC coverage 0.897 (target 0.90), but the worst-covered crop only 0.605. The guarantee is marginal, not per crop.

## Algorithms

Included: Logistic Regression, Gaussian NB, KNN, RBF-SVM, Decision Tree, Random Forest, Extra Trees, Hist. Gradient Boosting, XGBoost, LightGBM, CatBoost, MLP, AdaBoost, Bagging, Soft Voting, Stacking; on district data also class-balanced RF and LightGBM, and a prior (class-frequency) baseline. TabPFN v2 via flag.

Worth adding for the real data:
1. TabPFN v2 (Hollmann et al., Nature 2025). Designed for ≤10k rows; the 2010–2017 window fits.
2. Learning-to-rank (LightGBM `LGBMRanker`, LambdaRank): implemented in `08_district_ranking.py`. Ranks all crops per district-year by area share and reports NDCG@3, which matches what a recommender actually outputs.
3. Classifier chains for the multi-label task, to use crop co-occurrence (e.g. rice–wheat rotation).
4. FT-Transformer (Gorishniy et al., NeurIPS 2021) as the deep-tabular baseline. Expect GBDTs to stay competitive (Grinsztajn et al., NeurIPS 2022).

Not worth it: more ensembles on Kaggle (ceiling reached), GAN/CTGAN augmentation of Kaggle rows, CNN/LSTM on static tabular features. SMOTE only inside training folds and never with spatial CV leakage.

## Still to run for the paper

1. Attach Soil Health Card district data + DLD rainfall, rebuild, run 07. This is the headline result.
2. Label-threshold sensitivity: rebuild with `--share-threshold 0.03` and `0.10`, rerun 07.
3. TabPFN on Colab (both datasets).
4. Hyperparameters are fixed defaults. Either say so, or add nested CV tuning for the top 3 models on the district data.
5. Soil-only vs climate-only on district data under leave-state-out (commands above).
6. Report hardware and runtimes (in tab02 already for Kaggle).
7. Re-download the ICRISAT table from the DLD portal and diff against the mirror copy.

## Method references

Nadeau & Bengio 2003 (Machine Learning 52); Bouckaert & Frank 2004 (PAKDD) — corrected resampled t-test. Sadinle, Lei & Wasserman 2019 (JASA) — LAC sets. Romano, Sesia & Candès 2020 (NeurIPS) — APS. Angelopoulos & Bates 2021 (arXiv:2107.07511) — conformal tutorial. Guo et al. 2017 (ICML) — calibration/ECE. Roberts et al. 2017 (Ecography) and Ploton et al. 2020 (Nature Communications) — spatial cross-validation. Lundberg & Lee 2017 (NeurIPS) — SHAP. Hollmann et al. 2025 (Nature) — TabPFN.
